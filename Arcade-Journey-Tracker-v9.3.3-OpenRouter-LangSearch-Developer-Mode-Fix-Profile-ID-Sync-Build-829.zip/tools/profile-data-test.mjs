import test from 'node:test';
import assert from 'node:assert/strict';
import { _test as helpers } from '../netlify/functions/profile-data.mjs';

const { uidForUrl, validProfileUrl, cleanSnapshot, cleanData, recordKey } = helpers;
const uid = '12345678-abcd-1234-abcd-123456789abc';
const url = `https://www.skills.google/public_profiles/${uid}`;

test('public Google Skills profile ID is derived from the URL and validated', () => {
  assert.equal(uidForUrl(url), uid);
  assert.equal(validProfileUrl(url, uid), true);
  assert.equal(validProfileUrl(`https://example.com/public_profiles/${uid}`, uid), false);
  assert.equal(validProfileUrl(`http://www.skills.google/public_profiles/${uid}`, uid), false);
  assert.match(recordKey(uid), /^profile-[a-f0-9]{40}$/);
});

test('profile snapshot keeps badge data and removes unrelated fields', () => {
  const snap = cleanSnapshot({ url, name: 'Arcade Tester', league: 'Gold League', pages: 2, t: Date.now(), badges: [
    { key: 'Badge A|2026-11-01', title: 'Badge A', date: '2026-11-01', sk: true, extra: 'discard' },
    { key: 'Badge B|2026-11-02', title: 'Badge B', date: '2026-11-02', sk: null }
  ] });
  assert.equal(snap.name, 'Arcade Tester');
  assert.equal(snap.badges.length, 2);
  assert.equal(snap.badges[0].sk, true);
  assert.equal('extra' in snap.badges[0], false);
  assert.equal(cleanSnapshot({ url, badges: 'not-an-array' }), null);
});

test('profile-ID record preserves manual overrides, classifications, bonus points and settings', () => {
  const data = cleanData({
    snapshot: { url, name: 'Arcade Tester', badges: [{ key: 'A|2026-01-01', title: 'A', date: '2026-01-01', sk: null }] },
    profiles: [{ url, snap: { url, name: 'Arcade Tester', badges: [{ title: 'A' }] } }, { url: 'https://www.skills.google/public_profiles/87654321-abcd-1234-abcd-123456789abc', snap: { url: 'https://www.skills.google/public_profiles/87654321-abcd-1234-abcd-123456789abc', badges: [{ title: 'B' }] } }],
    overrides: { 'A|2026-01-01': 'game', bad: 'arbitrary' },
    learned: { 'badge stem': 'trivia', bad: 'special' },
    manualPoints: { [uid]: [{ id: 'a1', event: 'Manual event', points: 2.5, date: '2026-11-01' }, { event: 'bad', points: -1, date: 'bad' }], '87654321-abcd-1234-abcd-123456789abc': [{ id: 'b1', event: 'Other profile', points: 4, date: '2026-11-01' }] },
    config: { fac: true, bms: true, every: 15, unexpected: true },
    goal: 'Champion', customGoal: 180, gameKeywords: ['Arcade event'], skillKeywords: ['Cloud badge'], seasonYear: 2026
  }, uid);
  assert.equal(data.uid, uid);
  assert.equal(data.version, 2);
  assert.equal(data.snapshot.url, url);
  assert.equal(data.profiles.length, 1);
  assert.equal(data.profiles[0].url, url);
  assert.deepEqual(data.overrides, { 'A|2026-01-01': 'game' });
  assert.deepEqual(data.learned, { 'badge stem': 'trivia' });
  assert.deepEqual(data.manualPoints, { [uid]: [{ id: 'a1', event: 'Manual event', points: 2.5, date: '2026-11-01' }] });
  assert.equal(data.config.fac, true);
  assert.equal('unexpected' in data.config, false);
  assert.equal(data.goal, 'Champion');
  assert.equal(data.customGoal, 180);
});

test('a profile URL cannot be stored under a different profile ID', () => {
  assert.throws(() => cleanData({ snapshot: { url, badges: [{ title: 'A' }] } }, 'another-profile-id'), /does not match/);
});
