'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');

const salt = '00112233445566778899aabbccddeeff';
const testPassword = 'community-catalog-test-password';
process.env.ADMIN_PASSWORD_HASH = `${salt}:${crypto.scryptSync(testPassword, Buffer.from(salt, 'hex'), 32, { N: 16384, r: 8, p: 1 }).toString('hex')}`;
process.env.TOKEN_SECRET = 'community-catalog-test-secret-that-is-long-enough';

const api = require('../netlify/functions/community.js');
const store = new Map();
const oldFetch = global.fetch;

global.fetch = async (input, init = {}) => {
  const key = decodeURIComponent(new URL(String(input)).pathname.split('/').pop());
  const method = String(init.method || 'GET').toUpperCase();
  if (method === 'GET') {
    const exists = store.has(key);
    return { status: exists ? 200 : 404, ok: exists, text: async () => store.get(key) || '' };
  }
  if (method === 'PUT') {
    store.set(key, String(init.body || ''));
    return { status: 200, ok: true, text: async () => '' };
  }
  if (method === 'DELETE') {
    store.delete(key);
    return { status: 200, ok: true, text: async () => '' };
  }
  return { status: 405, ok: false, text: async () => '' };
};

const blobs = Buffer.from(JSON.stringify({ url: 'https://blob.test', token: 'test-blob-token' })).toString('base64');
const headers = { 'x-nf-site-id': 'test-site' };
async function call(body, token) {
  return api.handler({
    httpMethod: 'POST',
    headers: { ...headers, ...(token ? { authorization: `Bearer ${token}` } : {}) },
    blobs,
    body: JSON.stringify(body),
  });
}

(async () => {
  const login = await call({ action: 'login', password: testPassword });
  assert.equal(login.statusCode, 200, 'developer login should issue a test token');
  const token = JSON.parse(login.body).token;

  const entries = [
    { title: 'Direct URL badge', aliases: ['Alternate Badge Name'], status: 'active', url: 'https://www.skills.google/course_templates/12345' },
    { title: 'Retired badge', aliases: [], status: 'retired', url: '' },
  ];
  const saved = await call({ action: 'catalog_save', entries, keywords: { game: [], skill: ['vertex ai'] } }, token);
  assert.equal(saved.statusCode, 200, 'catalogue save should be accepted');
  assert.equal(JSON.parse(saved.body).urlEntries, 1, 'direct URL count should be returned');

  const get = await api.handler({ httpMethod: 'GET', headers, blobs, queryStringParameters: {} });
  assert.equal(get.statusCode, 200, 'public catalogue should be readable');
  const result = JSON.parse(get.body).catalog.entries;
  assert.equal(result.find(x => x.title === 'Direct URL badge').url, 'https://www.skills.google/course_templates/12345');
  assert.equal(result.find(x => x.title === 'Retired badge').status, 'retired', 'retired state must persist on server');

  const before = store.get('catalog');
  const badHost = await call({ action: 'catalog_save', entries: [{ title: 'Unsafe badge', status: 'active', url: 'https://evil.example/' }] }, token);
  assert.equal(badHost.statusCode, 400, 'non-Google link must be rejected');
  assert.equal(store.get('catalog'), before, 'rejected URL must not overwrite the existing catalogue');
  const badScheme = await call({ action: 'catalog_save', entries: [{ title: 'Unsafe scheme badge', status: 'active', url: 'http://skills.google/course_templates/1' }] }, token);
  assert.equal(badScheme.statusCode, 400, 'non-HTTPS link must be rejected');
  const userInfo = await call({ action: 'catalog_save', entries: [{ title: 'Credential URL badge', status: 'active', url: 'https://name:pass@skills.google/course_templates/1' }] }, token);
  assert.equal(userInfo.statusCode, 400, 'URL user-info must be rejected');

  console.log('Community catalogue regression tests passed: direct badge URLs persist, retired state persists, and unsafe links are rejected.');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
}).finally(() => {
  global.fetch = oldFetch;
});
