import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeLangSearchPayload, searchLangSearch } from '../netlify/lib/arcade-buddy/langsearch-provider.mjs';
import { _test as openrouter } from '../netlify/lib/arcade-buddy/openrouter-agent.mjs';

test('LangSearch normalizes links and keeps community and official candidates distinct', () => {
  const results = normalizeLangSearchPayload({ data: { webPages: { value: [
    { name: 'Google Skills', url: 'https://skills.google/path', text: 'Official candidate text', datePublished: '2026-11-01' },
    { name: 'Community report', url: 'https://www.reddit.com/r/example', snippet: 'Community text' },
    { name: 'Bad URL', url: 'javascript:alert(1)' }
  ] } } });
  assert.equal(results.length, 2);
  assert.equal(results[0].evidenceClass, 'official-candidate');
  assert.equal(results[0].verificationStatus, 'unverified_search_result');
  assert.equal(results[1].evidenceClass, 'community');
});

test('LangSearch requires a key and posts to the documented endpoint', async () => {
  const missing = await searchLangSearch('test', { apiKey: '' });
  assert.equal(missing.reason, 'not_configured');
  let request;
  const result = await searchLangSearch('Google Skills Arcade updates', {
    apiKey: 'test-key',
    fetchImpl: async (url, init) => {
      request = { url, init };
      return new Response(JSON.stringify({ code: '200', data: { webPages: { value: [{ name: 'Result', url: 'https://example.com/a', snippet: 'Evidence' }] } } }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
  });
  assert.equal(result.ok, true);
  assert.equal(result.results[0].url, 'https://example.com/a');
  assert.equal(request.url, 'https://api.langsearch.com/v1/web-search');
  assert.equal(request.init.headers.authorization, 'Bearer test-key');
});

test('OpenRouter parses search tool queries and defaults to the free model router', () => {
  assert.equal(openrouter.MODEL_DEFAULT, 'openrouter/free');
  assert.equal(openrouter.toolQuery('{"query":"latest Arcade rules"}'), 'latest Arcade rules');
  assert.equal(openrouter.toolQuery('not-json'), '');
});

test('OpenRouter request fails safely when no server key is configured', async () => {
  const result = await openrouter.requestCompletion([{ role: 'user', content: 'hi' }], { apiKey: '' });
  assert.equal(result.ok, false);
  assert.equal(result.reason, 'not_configured');
});

test('Arcade Buddy fetches LangSearch evidence before asking OpenRouter for a current answer', async () => {
  let searchCalled = false;
  let modelRequest = null;
  const answer = await (await import('../netlify/lib/arcade-buddy/openrouter-agent.mjs')).generateOpenRouterAnswer({
    question: 'What are the latest Google Skills Arcade updates?',
    history: [],
    evidence: [],
    calculator: { totals: { currentPoints: 12 } },
    researchRequested: true
  }, {
    apiKey: 'openrouter-test-key',
    langSearchApiKey: 'langsearch-test-key',
    langSearchFetchImpl: async (url, init) => {
      searchCalled = true;
      assert.equal(url, 'https://api.langsearch.com/v1/web-search');
      return new Response(JSON.stringify({ code: '200', data: { webPages: { value: [
        { name: 'Official candidate', url: 'https://skills.google/example', text: 'An unverified search lead.' }
      ] } } }), { status: 200, headers: { 'content-type': 'application/json' } });
    },
    fetchImpl: async (url, init) => {
      modelRequest = { url, body: JSON.parse(init.body) };
      return new Response(JSON.stringify({
        model: 'openrouter/free:test-model',
        choices: [{ message: { role: 'assistant', content: 'I found one unverified search lead. Check the official page before relying on it.' } }]
      }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
  });
  assert.equal(searchCalled, true);
  assert.equal(modelRequest.url, 'https://openrouter.ai/api/v1/chat/completions');
  assert.ok(modelRequest.body.messages.some(item => String(item.content || '').includes('LangSearch results')));
  assert.equal(answer.ok, true);
  assert.equal(answer.webSearchUsed, true);
  assert.equal(answer.sources[0].evidenceClass, 'official-candidate');
});


test('OpenRouter retries a free model without optional tools when that model rejects tool calls', async () => {
  let calls = 0;
  const answer = await (await import('../netlify/lib/arcade-buddy/openrouter-agent.mjs')).generateOpenRouterAnswer({
    question: 'What changed in Arcade this week?',
    calculator: {},
    researchRequested: true
  }, {
    apiKey: 'openrouter-test-key',
    langSearchApiKey: 'langsearch-test-key',
    langSearchFetchImpl: async () => new Response(JSON.stringify({ code: '200', data: { webPages: { value: [
      { name: 'Search lead', url: 'https://example.com/arcade', text: 'Unverified current lead.' }
    ] } } }), { status: 200, headers: { 'content-type': 'application/json' } }),
    fetchImpl: async (url, init) => {
      calls += 1;
      const body = JSON.parse(init.body);
      if (calls === 1) {
        assert.ok(Array.isArray(body.tools) && body.tools.length === 1);
        return new Response(JSON.stringify({ error: { message: 'This model does not support tool calls.' } }), { status: 400 });
      }
      assert.equal(body.tools, undefined);
      return new Response(JSON.stringify({ model: 'openrouter/free:fallback', choices: [{ message: { role: 'assistant', content: 'Here is the cautious summary.' } }] }), { status: 200 });
    }
  });
  assert.equal(calls, 2);
  assert.equal(answer.ok, true);
  assert.equal(answer.webSearchUsed, true);
});

test('External prompts remove email addresses and Google Skills public-profile URLs', () => {
  const { redactExternalText } = openrouter;
  const result = redactExternalText('Please check https://www.skills.google/public_profiles/12345678-abcd and email me at learner@example.com.');
  assert.doesNotMatch(result, /12345678-abcd|learner@example\.com/);
  assert.match(result, /\[profile URL removed\]/);
  assert.match(result, /\[email removed\]/);
});
