import crypto from 'node:crypto';

// Public-profile-ID sync. This is intentionally not an authenticated/private store:
// a Google Skills public profile ID is public and is not proof of ownership.
const STORE_NAME = 'arcade-profile-id-sync';
const MAX_BODY_BYTES = 2 * 1024 * 1024;
const rate = new Map();
const ALLOWED_HOSTS = new Set(['skills.google', 'www.skills.google', 'cloudskillsboost.google', 'www.cloudskillsboost.google']);
const json = (payload, status = 200) => Response.json(payload, {
  status,
  headers: { 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }
});

function uidForUrl(value) {
  const raw = String(value || '');
  const match = raw.match(/public_profiles\/([a-z0-9-]{8,64})/i);
  return match ? match[1].toLowerCase() : '';
}
function validProfileUrl(value, uid) {
  try {
    const u = new URL(String(value || ''));
    return u.protocol === 'https:' && ALLOWED_HOSTS.has(u.hostname.toLowerCase())
      && /^\/public_profiles\/[a-z0-9-]{8,64}\/?$/i.test(u.pathname)
      && uidForUrl(u.toString()) === String(uid || '').toLowerCase();
  } catch { return false; }
}
function recordKey(uid) {
  return 'profile-' + crypto.createHash('sha256').update(String(uid).toLowerCase()).digest('hex').slice(0, 40);
}
const asObject = value => value && typeof value === 'object' && !Array.isArray(value) ? value : {};
const boundedText = (value, max) => String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);

function cleanMap(value, allowedValues = null, max = 3000) {
  const output = {};
  for (const [key, rawValue] of Object.entries(asObject(value)).slice(0, max)) {
    const cleanKey = boundedText(key, 260);
    const cleanValue = boundedText(rawValue, 30);
    if (cleanKey && (!allowedValues || allowedValues.has(cleanValue))) output[cleanKey] = cleanValue;
  }
  return output;
}

function cleanSnapshot(value) {
  if (!value || typeof value !== 'object' || !Array.isArray(value.badges) || value.badges.length > 5000) return null;
  const url = boundedText(value.url, 500);
  const uid = uidForUrl(url);
  if (!uid || !validProfileUrl(url, uid)) return null;
  const badges = value.badges.map(badge => {
    if (!badge || typeof badge !== 'object') return null;
    const title = boundedText(badge.title, 180);
    const date = /^\d{4}-\d{2}-\d{2}$/.test(String(badge.date || '')) ? String(badge.date) : null;
    if (!title) return null;
    const item = {
      key: boundedText(badge.key || (title + '|' + (date || '')), 260),
      title,
      date,
      sk: badge.sk === true ? true : badge.sk === false ? false : null
    };
    if (badge.iu) item.iu = boundedText(badge.iu, 500);
    if (badge.img && typeof badge.img === 'object') {
      item.img = {
        k: boundedText(badge.img.k, 30),
        score: Number.isFinite(Number(badge.img.score)) ? Math.max(0, Math.min(1, Number(badge.img.score))) : 0
      };
    }
    return item;
  }).filter(Boolean);
  return {
    url,
    name: boundedText(value.name || 'Learner', 60),
    league: boundedText(value.league, 60) || null,
    since: boundedText(value.since, 60) || null,
    noModal: value.noModal === true,
    pages: Math.max(1, Math.min(100, Math.round(Number(value.pages) || 1))),
    badges,
    t: Math.max(0, Math.min(Date.now() + 86400000, Number(value.t) || Date.now())),
    src: 'fetch'
  };
}

function cleanProfileList(value, uid) {
  if (!Array.isArray(value)) return [];
  const output = [];
  for (const profile of value.slice(0, 5)) {
    const snapshot = cleanSnapshot(profile && profile.snap);
    if (!snapshot || uidForUrl(snapshot.url) !== uid) continue;
    output.push({
      url: snapshot.url,
      name: snapshot.name,
      league: snapshot.league,
      badges: snapshot.badges.length,
      savedAt: Math.max(0, Math.min(Date.now() + 86400000, Number(profile.savedAt) || Date.now())),
      snap: snapshot
    });
  }
  return output;
}

function cleanManualPoints(value, profileUid) {
  const output = {};
  for (const [uid, entries] of Object.entries(asObject(value)).slice(0, 8)) {
    if (!/^[a-z0-9-]{8,64}$/i.test(uid) || uid.toLowerCase() !== profileUid || !Array.isArray(entries)) continue;
    output[uid.toLowerCase()] = entries.slice(-200).map(item => {
      const points = Number(item && item.points);
      const date = String(item && item.date || '');
      if (!Number.isFinite(points) || points < 0.5 || points > 1000 || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
      return {
        id: boundedText(item.id, 40) || Date.now().toString(36),
        event: boundedText(item.event, 80),
        points: Math.round(points * 100) / 100,
        date
      };
    }).filter(item => item && item.event.length >= 2);
  }
  return output;
}

function cleanConfig(value) {
  const source = asObject(value), output = {};
  for (const key of ['live', 'win', 'floor', 'fac', 'bms', 'img', 'fest', 'seas']) {
    if (typeof source[key] === 'boolean') output[key] = source[key];
  }
  if ([0.5, 1, 2, 5, 15].includes(Number(source.every))) output.every = Number(source.every);
  if (['yes', 'no'].includes(source.unk)) output.unk = source.unk;
  return output;
}

function cleanData(raw, uid) {
  const source = asObject(raw);
  const snapshot = cleanSnapshot(source.snapshot);
  if (snapshot && uidForUrl(snapshot.url) !== uid) throw new Error('Profile URL does not match its storage ID.');
  const profiles = cleanProfileList(source.profiles, uid);
  const keywords = value => Array.isArray(value)
    ? [...new Set(value.map(item => boundedText(item, 90).toLowerCase()).filter(item => item.length >= 3))].slice(0, 150)
    : [];
  const snapshots = Array.isArray(source.snapshots) ? source.snapshots.slice(-60).map(item => ({
    t: Math.max(0, Number(item.t) || 0),
    b: Math.max(0, Math.min(5000, Number(item.b) || 0)),
    a: Math.max(0, Math.min(5000, Number(item.a) || 0)),
    p: Math.max(0, Math.min(10000, Number(item.p) || 0)),
    v: boundedText(item.v, 60)
  })) : [];
  const updates = Array.isArray(source.updates) ? source.updates.slice(0, 100).map(item => ({
    id: boundedText(item.id, 40),
    t: Math.max(0, Number(item.t) || 0),
    k: boundedText(item.k, 30),
    title: boundedText(item.title, 150),
    date: boundedText(item.date, 20),
    pts: Math.max(0, Math.min(10000, Number(item.pts) || 0)),
    note: boundedText(item.note, 240),
    n: item.n ? 1 : 0
  })) : [];
  const goal = ['Trooper', 'Ranger', 'Champion', 'Legend', 'Custom'].includes(source.goal) ? source.goal : 'Legend';
  const customGoal = Math.max(50, Math.min(5000, Number(source.customGoal) || 100));
  const maxSeason = new Date().getUTCFullYear();
  const seasonYear = Number.isInteger(Number(source.seasonYear)) && Number(source.seasonYear) >= 2026 && Number(source.seasonYear) <= maxSeason
    ? Number(source.seasonYear) : maxSeason;
  return {
    version: 2,
    uid,
    savedAt: Date.now(),
    snapshot,
    profiles,
    seasonYear,
    overrides: cleanMap(source.overrides, new Set(['game', 'trivia', 'special', 'skill', 'no'])),
    learned: cleanMap(source.learned, new Set(['game', 'trivia'])),
    manualPoints: cleanManualPoints(source.manualPoints, uid),
    config: cleanConfig(source.config),
    goal,
    customGoal,
    gameKeywords: keywords(source.gameKeywords),
    skillKeywords: keywords(source.skillKeywords),
    snapshots,
    updates
  };
}

function allowedOrigin(request) {
  const origin = request.headers.get('origin');
  const host = request.headers.get('host');
  if (!origin || !host) return true;
  try { return new URL(origin).host === host; } catch { return false; }
}
function rateAllowed(request) {
  const ip = request.headers.get('x-nf-client-connection-ip') || 'unknown';
  const now = Date.now();
  const hits = (rate.get(ip) || []).filter(time => now - time < 60000);
  if (hits.length >= 120) { rate.set(ip, hits); return false; }
  hits.push(now);
  rate.set(ip, hits);
  return true;
}
function parseUid(value) {
  const uid = String(value || '').toLowerCase();
  return /^[a-z0-9-]{8,64}$/.test(uid) ? uid : '';
}

export default async function handler(request) {
  try {
    if (!allowedOrigin(request)) return json({ ok: false, error: 'Cross-site request blocked.' }, 403);
    if (!rateAllowed(request)) return json({ ok: false, error: 'Too many profile sync requests. Try again shortly.' }, 429);
    if (request.method !== 'GET' && request.method !== 'POST') return json({ ok: false, error: 'Method not allowed.' }, 405);

    const { getStore } = await import('@netlify/blobs');
    const store = getStore({ name: STORE_NAME, consistency: 'strong' });
    const url = new URL(request.url);

    if (request.method === 'GET') {
      const uid = parseUid(url.searchParams.get('uid'));
      if (!uid) return json({ ok: false, error: 'Invalid public profile ID.' }, 400);
      const entry = await store.getWithMetadata(recordKey(uid), { type: 'json', consistency: 'strong' });
      if (!entry) return json({ ok: true, exists: false, deleted: false, data: null, revision: null });
      if (entry.data?.deleted === true) return json({ ok: true, exists: false, deleted: true, data: null, revision: entry.etag || null });
      return json({ ok: true, exists: !!entry.data?.data, deleted: false, data: entry.data?.data || null, revision: entry.etag || null, savedAt: entry.data?.savedAt || null });
    }

    const raw = await request.text();
    if (Buffer.byteLength(raw, 'utf8') > MAX_BODY_BYTES) return json({ ok: false, error: 'Profile backup is too large.' }, 413);
    let body;
    try { body = JSON.parse(raw || '{}'); } catch { return json({ ok: false, error: 'Invalid JSON.' }, 400); }
    const uid = parseUid(body.uid);
    if (!uid) return json({ ok: false, error: 'Invalid public profile ID.' }, 400);
    const key = recordKey(uid);

    if (body.action === 'delete') {
      const current = await store.getMetadata(key, { consistency: 'strong' });
      let condition;
      if (current) {
        if (!body.revision || body.revision !== current.etag) return json({ ok: false, conflict: true, error: 'This profile changed on another device. Refresh before deleting.' }, 409);
        condition = { onlyIfMatch: body.revision };
      } else {
        if (body.revision) return json({ ok: false, conflict: true, error: 'This profile changed on another device. Refresh before deleting.' }, 409);
        condition = { onlyIfNew: true };
      }
      const result = await store.setJSON(key, { version: 2, deleted: true, savedAt: Date.now() }, {
        ...condition,
        metadata: { profileIdSync: true, deleted: true }
      });
      if (!result.modified) return json({ ok: false, conflict: true, error: 'This profile changed during deletion. Refresh and retry.' }, 409);
      return json({ ok: true, deleted: true, revision: result.etag || null });
    }

    if (body.action !== 'save') return json({ ok: false, error: 'Unknown profile sync action.' }, 400);
    const data = cleanData(body.data, uid);
    if (!data.snapshot) return json({ ok: false, error: 'A valid public Google Skills profile snapshot is required before syncing.' }, 400);
    const encoded = JSON.stringify(data);
    if (Buffer.byteLength(encoded, 'utf8') > MAX_BODY_BYTES) return json({ ok: false, error: 'Profile backup is too large.' }, 413);

    const options = body.revision
      ? { onlyIfMatch: String(body.revision) }
      : { onlyIfNew: true };
    const result = await store.setJSON(key, { version: 2, deleted: false, savedAt: Date.now(), data }, {
      ...options,
      metadata: { profileIdSync: true, profileId: uid, updatedAt: new Date().toISOString() }
    });
    if (!result.modified) return json({ ok: false, conflict: true, error: 'Saved profile changed on another device. Your local changes are preserved; refresh the profile before syncing again.' }, 409);
    return json({ ok: true, savedAt: Date.now(), revision: result.etag || null, bytes: Buffer.byteLength(encoded, 'utf8') });
  } catch (error) {
    console.error('[profile-data]', error?.message || error);
    return json({ ok: false, error: 'Profile sync failed. Local data has not been removed.' }, 500);
  }
}

export const _test = {
  uidForUrl, validProfileUrl, recordKey, cleanSnapshot, cleanData,
  storeName: STORE_NAME, maxBodyBytes: MAX_BODY_BYTES
};
