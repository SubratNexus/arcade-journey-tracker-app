#!/usr/bin/env python3
"""Apply the Arcade Journey Tracker v9.3.0 update to the checked-out 9.2.0 source."""
from pathlib import Path
import json
import re
import shutil
import sys

ROOT = Path.cwd()
PAYLOAD = ROOT / '.arcade-v930-payload'
EXPECTED_VERSION = '9.2.0'
EXPECTED_BUILD = '825'
NEW_VERSION = '9.3.0'
NEW_BUILD = '826'


def require_file(path: str) -> Path:
    item = ROOT / path
    if not item.is_file():
        raise SystemExit(f'Required source file is missing: {path}')
    return item


def read(path: str) -> str:
    return require_file(path).read_text(encoding='utf-8')


def write(path: str, content: str) -> None:
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding='utf-8', newline='\n')


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'Patch stopped safely: expected one {label}, found {count}.')
    return text.replace(old, new, 1)


def replace_regex_once(text: str, pattern: str, replacement: str, label: str, flags=0) -> str:
    updated, count = re.subn(pattern, replacement, text, count=1, flags=flags)
    if count != 1:
        raise SystemExit(f'Patch stopped safely: expected one {label}, found {count}.')
    return updated


def copy_payload() -> None:
    required = [
        'netlify/lib/arcade-buddy/langsearch-provider.mjs',
        'netlify/lib/arcade-buddy/openrouter-agent.mjs',
        'netlify/functions/profile-data.mjs',
        'tools/openrouter-langsearch-test.mjs',
        'tools/profile-data-test.mjs',
    ]
    for relative in required:
        source = PAYLOAD / relative
        if not source.is_file():
            raise SystemExit(f'Update ZIP is missing payload file: {relative}')
        destination = ROOT / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


SYNC_BLOCK = r'''const VK='arc.vid';let VID=ls.g(VK,null);if(!VID){VID=(crypto.randomUUID?crypto.randomUUID():'v'+Date.now()+Math.random().toString(16).slice(2));ls.s(VK,VID)}
const uidForUrl=u=>{u=String(u||'');const m=u.match(/public_profiles\/([a-z0-9-]{8,64})/i);return m?m[1].toLowerCase():''};
const uidOf=()=>uidForUrl(S&&S.url||''),MP=ls.g('manualPoints',{});
const cloudSavedRevisions=ls.g('arc.sync.revisions',{}),cloudSavedDirty=ls.g('arc.sync.dirty',[]);let arcadeCloudUser={kind:'profile-id-sync'},cloudSaveTimer=0,cloudApplying=false,cloudStatus='Profile-ID sync starts when a Google Skills public profile is loaded',cloudBlockedUids=new Set(),cloudRevisions=new Map(cloudSavedRevisions&&typeof cloudSavedRevisions==='object'?Object.entries(cloudSavedRevisions):[]),cloudDirtyUids=new Set(Array.isArray(cloudSavedDirty)?cloudSavedDirty.filter(x=>/^[a-z0-9-]{8,64}$/.test(x)):[]),cloudBootstrapped=new Set(),cloudBootstrapPromises=new Map();
function cloudRememberRevision(uid,revision){cloudRevisions.set(uid,revision||null);ls.s('arc.sync.revisions',Object.fromEntries(cloudRevisions))}
function cloudMarkDirty(uid){cloudDirtyUids.add(uid);ls.s('arc.sync.dirty',[...cloudDirtyUids])}
function cloudClearDirty(uid){cloudDirtyUids.delete(uid);ls.s('arc.sync.dirty',[...cloudDirtyUids])}
function cloudStatusPaint(){const e=$('#cloudSaveStatus');if(e)e.textContent='Profile-ID sync: '+cloudStatus}
function cloudStatusSet(value){cloudStatus=value;cloudStatusPaint()}
function cloudSnapshotData(){const uid=uidOf();return{snapshot:S,profiles:typeof pfList==='function'?pfList().filter(p=>uidForUrl(p&&p.url)===uid):[],overrides:ov,learned:LEARN,manualPoints:uid?{[uid]:Array.isArray(MP[uid])?MP[uid]:[]}:{},config:cfg,goal,customGoal:ls.g('cg',100),seasonYear:SEASON,gameKeywords:KW,skillKeywords:SKW,snapshots:ls.g('snaps',[]),updates:ls.g('upd',[])}}
function arcAccountMarkup(){return `<div id="arcAccountSync" class="m" style="line-height:1.55"><b>Automatic profile-ID sync · no email or password</b><p style="margin:6px 0">Manual points, badge classifications, overrides, goals and settings are saved on this device and synced for the same Google Skills public profile ID when online.</p><p style="margin:6px 0;color:var(--w)">Important: the public profile ID is not proof of ownership. Anyone who knows it may be able to read, overwrite or delete its sync record. Do not store private information here.</p><div id="arcProfileSyncId" class="m">No public profile loaded yet.</div></div>`}
function arcAccountPaint(){const box=$('#arcProfileSyncId');if(box){const uid=uidOf();box.textContent=uid?'Sync profile ID: '+uid:'No public profile loaded yet.'}}
function profileCloudFetch(uid){if(!uid)return Promise.resolve({ok:false,error:'No public profile ID.'});const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),12000);return fetch('/api/profile-data?uid='+encodeURIComponent(uid),{cache:'no-store',credentials:'same-origin',headers:{'cache-control':'no-cache'},signal:ctrl.signal}).then(async r=>{const j=await r.json().catch(()=>({}));if(!r.ok||!j||!j.ok){if(r.status!==401)cloudBlockedUids.add(uid);return{ok:false,error:j.error||'Profile sync could not be read.'}}cloudBlockedUids.delete(uid);cloudRevisions.set(uid,j.revision||null);return j}).catch(e=>{cloudBlockedUids.add(uid);return{ok:false,error:e.name==='AbortError'?'Profile sync timed out.':'Profile sync could not be reached.'}}).finally(()=>clearTimeout(timer))}
function profileCloudApply(uid,data,restoreSnapshot){if(!data||String(data.uid||uid)!==uid)return;cloudBlockedUids.delete(uid);cloudApplying=true;try{
  if(Array.isArray(data.profiles)){const merged=new Map();[...data.profiles,...(typeof pfList==='function'?pfList():[])].forEach(p=>{if(p&&p.url)merged.set(p.url,p)});ls.s('profiles',[...merged.values()].sort((a,b)=>(b.savedAt||0)-(a.savedAt||0)).slice(0,5))}
  if(data.manualPoints&&typeof data.manualPoints==='object'){const entries=data.manualPoints[uid];if(Array.isArray(entries))MP[uid]=entries;else delete MP[uid];}ls.s('manualPoints',MP);
  ov=data.overrides&&typeof data.overrides==='object'?data.overrides:{};LEARN=data.learned&&typeof data.learned==='object'?data.learned:{};cfg=Object.assign({live:true,every:1,unk:'no',win:true,floor:false,fac:false,bms:false,img:true,fest:true,seas:true},data.config&&typeof data.config==='object'?data.config:{});
  goal=['Trooper','Ranger','Champion','Legend','Custom'].includes(data.goal)?data.goal:'Legend';const savedSeason=Number(data.seasonYear);if(Number.isInteger(savedSeason)&&savedSeason>=SEASON_MIN&&savedSeason<=curYear()){SEASON=savedSeason;ls.s('seasonPick',savedSeason===curYear()?0:savedSeason);setSeason(savedSeason)}KW=Array.isArray(data.gameKeywords)?data.gameKeywords:[];SKW=Array.isArray(data.skillKeywords)?data.skillKeywords:[];
  ls.s('ov',ov);ls.s('learn',LEARN);ls.s('cfg',cfg);ls.s('goal',goal);ls.s('kw',KW);ls.s('skw',SKW);ls.s('cg',Number(data.customGoal)||100);
  if(Array.isArray(data.snapshots))ls.s('snaps',data.snapshots);if(Array.isArray(data.updates))ls.s('upd',data.updates);
  const snap=data.snapshot;if(restoreSnapshot&&snap&&snap.url&&uidForUrl(snap.url)===uid&&(!S||S.url===snap.url)&&Number(snap.t)>=Number(S&&S.t||0)){S=snap;ls.s('state',S)}
  if(S&&S.url&&uidOf()===uid&&typeof pfSave==='function')pfSave(S);
  rebuildCatalog(mergeAllCatalog());buildRX();applySeason();
}finally{cloudApplying=false}}
async function profileCloudSaveNow(fromBootstrap=false){clearTimeout(cloudSaveTimer);if(cloudApplying||!S||!S.url)return false;const uid=uidOf();if(!uid)return false;if(!fromBootstrap&&!cloudBootstrapped.has(uid)){profileCloudBootstrap();return false}if(cloudBlockedUids.has(uid)){cloudStatusSet('Sync paused · local copy kept because the remote profile could not be checked');return false}cloudStatusSet('Saving changes…');const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),14000);try{const revision=cloudRevisions.has(uid)?cloudRevisions.get(uid):null;const r=await fetch('/api/profile-data',{method:'POST',headers:{'content-type':'application/json'},credentials:'same-origin',body:JSON.stringify({action:'save',uid,revision,data:cloudSnapshotData()}),cache:'no-store',signal:ctrl.signal});const j=await r.json().catch(()=>({}));if(r.status===409||j.conflict){cloudBlockedUids.add(uid);cloudStatusSet('Another device changed this profile. Your local data is preserved; reload the profile before syncing again.');return false}if(!r.ok||!j.ok)throw new Error(j.error||'Profile sync unavailable');cloudRememberRevision(uid,j.revision||null);cloudClearDirty(uid);cloudBlockedUids.delete(uid);cloudStatusSet('Saved · '+new Date(j.savedAt||Date.now()).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}));return true}catch(e){cloudStatusSet('Not synced · local copy kept');return false}finally{clearTimeout(timer)}}
function profileCloudSchedule(isUserEdit=true){if(cloudApplying||!S||!S.url)return;const uid=uidOf();if(!uid)return;if(isUserEdit)cloudMarkDirty(uid);if(!cloudBootstrapped.has(uid)){cloudStatusSet('Checking this profile for earlier saved changes…');profileCloudBootstrap().then(ok=>{if(ok&&S&&uidOf()===uid&&cloudDirtyUids.has(uid))profileCloudSchedule(false)});return}if(cloudBlockedUids.has(uid)){cloudStatusSet('Sync paused · local copy kept because the shared profile changed');return}clearTimeout(cloudSaveTimer);cloudStatusSet('Changes waiting to sync…');cloudSaveTimer=setTimeout(()=>profileCloudSaveNow(),450)}
function profileCloudKeepalive(){if(cloudApplying||!S||!S.url)return;const uid=uidOf();if(cloudDirtyUids.has(uid)&&cloudBootstrapped.has(uid)&&!cloudBlockedUids.has(uid)){clearTimeout(cloudSaveTimer);profileCloudSaveNow()}}
window.addEventListener('pagehide',profileCloudKeepalive);window.addEventListener('online',()=>{if(S&&S.url){const uid=uidOf();if(!cloudBootstrapped.has(uid))profileCloudBootstrap();else if(cloudDirtyUids.has(uid)&&!cloudBlockedUids.has(uid))profileCloudSaveNow()}});document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden'){clearTimeout(cloudSaveTimer);profileCloudKeepalive()}});
function profileCloudClearDeleted(uid){if(MP&&typeof MP==='object')delete MP[uid];ls.s('manualPoints',MP);ov={};LEARN={};cfg={live:true,every:1,unk:'no',win:true,floor:false,fac:false,bms:false,img:true,fest:true,seas:true};goal='Legend';KW=[];SKW=[];ls.s('ov',ov);ls.s('learn',LEARN);ls.s('cfg',cfg);ls.s('goal',goal);ls.s('kw',KW);ls.s('skw',SKW);ls.s('snaps',[]);ls.s('upd',[])}
async function profileCloudLoad(uid,restoreSnapshot){if(uid!==uidOf())return null;cloudBootstrapped.delete(uid);const knownRevision=cloudRevisions.has(uid)?cloudRevisions.get(uid):null,result=await profileCloudFetch(uid);if(!result||!result.ok)return null;const hadLocalEdits=cloudDirtyUids.has(uid);if(result.exists&&result.data){if(hadLocalEdits){if(knownRevision&&knownRevision===result.revision){cloudBootstrapped.add(uid);cloudRememberRevision(uid,result.revision);return await profileCloudSaveNow(true)?true:null}cloudBlockedUids.add(uid);cloudBootstrapped.add(uid);cloudStatusSet('This profile has unsynced local changes and a newer cloud copy. Both copies are preserved; syncing is paused.');return null}profileCloudApply(uid,result.data,!!restoreSnapshot);cloudBootstrapped.add(uid);cloudRememberRevision(uid,result.revision);cloudClearDirty(uid);cloudStatusSet('Earlier profile changes restored');return true}if(hadLocalEdits&&result.revision&&knownRevision!==result.revision){cloudBlockedUids.add(uid);cloudBootstrapped.add(uid);cloudStatusSet('This profile has unsynced local changes and a changed cloud record. Both copies are preserved; syncing is paused.');return null}if(result.deleted&&!hadLocalEdits){profileCloudClearDeleted(uid);cloudBootstrapped.add(uid);cloudRememberRevision(uid,result.revision||null);cloudClearDirty(uid);cloudStatusSet('Cloud data for this profile was cleared');return true}if(!hadLocalEdits){ov={};LEARN={};cfg={live:true,every:1,unk:'no',win:true,floor:false,fac:false,bms:false,img:true,fest:true,seas:true};goal='Legend';KW=[];SKW=[];ls.s('ov',ov);ls.s('learn',LEARN);ls.s('cfg',cfg);ls.s('goal',goal);ls.s('kw',KW);ls.s('skw',SKW);ls.s('snaps',[]);ls.s('upd',[])}cloudBootstrapped.add(uid);cloudRememberRevision(uid,result.revision||null);return await profileCloudSaveNow(true)?true:null}
async function profileCloudBootstrap(){if(!S||!S.url)return false;const uid=uidOf();if(!uid)return false;if(cloudBootstrapped.has(uid))return true;if(cloudBootstrapPromises.has(uid))return cloudBootstrapPromises.get(uid);const promise=(async()=>{const localStamp=Number(S&&S.t)||0,knownRevision=cloudRevisions.has(uid)?cloudRevisions.get(uid):null;const result=await profileCloudFetch(uid);if(!result||!result.ok){cloudStatusSet('Sync unavailable · your local data remains safe');return false}const hadLocalEdits=cloudDirtyUids.has(uid);if(result.exists&&result.data){if(hadLocalEdits){if(knownRevision&&knownRevision===result.revision){cloudBootstrapped.add(uid);cloudRememberRevision(uid,result.revision);const saved=await profileCloudSaveNow(true);if(saved)cloudStatusSet('Offline changes synced safely');return saved}cloudBlockedUids.add(uid);cloudBootstrapped.add(uid);cloudStatusSet('This device has unsynced changes and the cloud copy has also changed. Both copies are preserved; sync is paused to avoid overwriting either copy.');return false}profileCloudApply(uid,result.data,true);if(S&&uidOf()===uid&&Number(S.t)!==localStamp)pfSave(S);cloudBootstrapped.add(uid);cloudRememberRevision(uid,result.revision);cloudClearDirty(uid);render();cloudStatusSet('Earlier profile changes restored');return true}if(result.deleted&&!hadLocalEdits){profileCloudClearDeleted(uid);cloudBootstrapped.add(uid);cloudRememberRevision(uid,result.revision||null);cloudClearDirty(uid);cloudStatusSet('Cloud data for this profile was cleared');render();return true}cloudBootstrapped.add(uid);cloudRememberRevision(uid,result.revision||null);const saved=await profileCloudSaveNow(true);if(saved)cloudStatusSet('Automatic profile sync is ready');return saved})().finally(()=>cloudBootstrapPromises.delete(uid));cloudBootstrapPromises.set(uid,promise);return promise}
async function profileCloudRecover(uid,url,promise){try{const result=await promise;if(!result||!result.ok||!result.exists||!result.data||!result.data.snapshot||uidForUrl(result.data.snapshot.url)!==uid||cloudDirtyUids.has(uid))return false;cloudRememberRevision(uid,result.revision||null);profileCloudApply(uid,result.data,true);if(!S||uidForUrl(S.url)!==uid)return false;pfSave(S);view='home';render();cloudBootstrapped.add(uid);cloudClearDirty(uid);cloudStatusSet('Saved profile restored after a refresh problem');toast('Your saved profile and manual changes were restored.');return true}catch{return false}}
async function profileCloudDelete(uid){if(!uid)return false;let revision=cloudRevisions.has(uid)?cloudRevisions.get(uid):null;try{if(!cloudRevisions.has(uid)){const current=await profileCloudFetch(uid);if(!current||!current.ok)return false;revision=current.revision||null}const r=await fetch('/api/profile-data',{method:'POST',headers:{'content-type':'application/json'},credentials:'same-origin',body:JSON.stringify({action:'delete',uid,revision}),cache:'no-store'});const j=await r.json().catch(()=>({}));if(!r.ok||!j.ok)return false;cloudRememberRevision(uid,j.revision||null);cloudClearDirty(uid);cloudBootstrapped.delete(uid);cloudBlockedUids.delete(uid);return true}catch{return false}}
function arcAccountSyncNow(){if(!S||!S.url){toast('Load a Google Skills public profile first.',1);return}profileCloudBootstrap().then(ok=>{if(ok)toast('Profile sync checked.');else toast('Sync is not ready. Your local data remains available.',1)})}
const manualEntries=p=>{const u=uidForUrl(p&&p.url);return u&&Array.isArray(MP[u])?MP[u]:[]};
'''


def patch_html(path: str) -> None:
    text = read(path)
    if 'name="app-build" content="825"' not in text:
        raise SystemExit(f'{path} is not the expected Build 825 source.')
    text = replace_once(text, 'name="app-build" content="825"', 'name="app-build" content="826"', f'{path} build marker')
    text = replace_once(text, 'var BASE_BUILD = 825;', 'var BASE_BUILD = 826;', f'{path} hot-update baseline')
    start = text.find("const VK='arc.vid';")
    end = text.find('const manualEntries=p=>', start)
    if start < 0 or end < 0:
        raise SystemExit(f'{path} cloud-sync section anchors were not found.')
    text = text[:start] + SYNC_BLOCK + text[text.find('\n', end):]
    text = text.replace('<script type="module" src="/arcade-identity.js"></script>', '')
    if 'arcadeIdentity' in text or 'arcAccountLogin' in text or 'arcAccountSignup' in text or 'arcAccountPassword' in text:
        raise SystemExit(f'{path} still contains old email/password identity UI after patch.')
    text = replace_regex_once(text,
        r"(async function startImageScan\(snap\)\{[\s\S]*?pfSave\(S\);)profileCloudSchedule\(\);render\(\)",
        r"\1profileCloudSchedule(false);render()",
        f'{path} background image scan sync')
    text = replace_once(text,
        "ls.s('prevPts',pc?pc.tot:0);S=ns;ls.s('state',S);pfSave(ns);seasonSync();profileCloudSchedule();",
        "ls.s('prevPts',pc?pc.tot:0);S=ns;ls.s('state',S);pfSave(ns);seasonSync();profileCloudBootstrap();",
        f'{path} initial profile sync bootstrap')
    text = replace_once(text,
        "async function clearLocal(){if(!arcadeCloudUser){toast('Sign in to your Arcade account before deleting private cloud backups.',1);return}if(!confirm('Clear My Data will permanently delete the saved cloud backup",
        "async function clearLocal(){if(!confirm('Clear My Data will permanently delete the saved profile-ID sync records",
        f'{path} Clear My Data sign-in removal')
    if 'Sign in to your Arcade account' in text:
        raise SystemExit(f'{path} still contains an old email/password sign-in prompt.')
    text = text.replace('Cloud backup: checking…', 'Profile-ID sync: checking…')
    text = text.replace('Checking Gemini…', 'Checking Arcade Buddy…')
    text = text.replace("j.externalAi?'Gemini configured · '+(j.aiModel||'ready'):'Gemini API key missing on this deployment'", "j.externalAi?'OpenRouter configured · '+(j.aiModel||'ready')+(j.webSearchConfigured?' · LangSearch ready':' · LangSearch not configured'):'OpenRouter API key missing on this deployment'")
    text = replace_once(text,
        "if(restored===false||restored===null){ov={};LEARN={};ls.s('ov',ov);ls.s('learn',LEARN);ls.s('snaps',[]);ls.s('upd',[])}",
        "if((restored===false||restored===null)&&!cloudBlockedUids.has(nextUid)&&!cloudDirtyUids.has(nextUid)){ov={};LEARN={};ls.s('ov',ov);ls.s('learn',LEARN);ls.s('snaps',[]);ls.s('upd',[])}",
        f'{path} profile-switch conflict protection')
    text = text.replace('Sign in to enable private cloud sync', 'Load a public Google Skills profile to enable automatic sync')
    text = replace_regex_once(text, r"async function logout\(\)\{[\s\S]*?\nfunction creditTag\(",
        "async function logout(){if(S&&S.url){const uid=uidOf();if(!cloudBootstrapped.has(uid))await profileCloudBootstrap();if(S&&S.url)await profileCloudSaveNow(true)}try{ls.s('state',null);ls.s('prevPts',0)}catch{}S=null;view='land';selMode=false;sel.clear();const o=$('#ov');if(o)o.innerHTML='';try{pfClose()}catch{}render();scrollTo(0,0);toast('Logged out. Your local data and profile-ID backup are kept.')}\nfunction creditTag(",
        f'{path} logout function')
    write(path, text)


def patch_intelligence() -> None:
    text = read('netlify/functions/intelligence.js')
    text = text.replace('A minimal, sanitised dashboard context and limited badge titles may be sent to Gemini when configured;',
                        'A minimal, sanitised dashboard context and limited badge titles may be sent to OpenRouter when configured;')
    text = replace_once(text,
        "function aiConfigured() {\n  const provider = String(process.env.AI_PROVIDER || 'gemini').toLowerCase();\n  return provider === 'gemini' && !!process.env.GEMINI_API_KEY;\n}\nfunction aiModelName() {\n  return String(process.env.GEMINI_MODEL || 'gemini-2.5-flash').trim() || 'gemini-2.5-flash';\n}",
        "function aiConfigured() {\n  return !!process.env.OPENROUTER_API_KEY;\n}\nfunction aiModelName() {\n  return String(process.env.OPENROUTER_MODEL || 'openrouter/free').trim() || 'openrouter/free';\n}",
        'Gemini AI configuration block')
    text = replace_once(text,
        "externalAi: aiConfigured(), aiProvider: aiConfigured() ? 'gemini' : null, aiModel: aiConfigured() ? aiModelName() : null,",
        "externalAi: aiConfigured(), aiProvider: aiConfigured() ? 'openrouter' : null, aiModel: aiConfigured() ? aiModelName() : null, webSearchConfigured: !!process.env.LANGSEARCH_API_KEY,",
        'AI health response')
    start = text.find('  let aiReply = null;')
    end = text.find('  const arcadeContextPattern =', start)
    if start < 0 or end < 0:
        raise SystemExit('Could not locate the chat provider execution block in intelligence.js.')
    ai_block = r'''  let aiReply = null;
  let aiModel = null;
  let aiFailureReason = null;
  let aiFailureMessage = null;
  let aiSearchEvidence = [];
  let aiWebSearchUsed = false;
  if (aiConfigured()) {
    try {
      const { generateOpenRouterAnswer } = await import('../lib/arcade-buddy/openrouter-agent.mjs');
      const aiResult = await generateOpenRouterAnswer({
        question: message,
        history,
        evidence: (research && Array.isArray(research.evidence)) ? research.evidence : [],
        strategy: (research && research.strategy) || null,
        calculator,
        timeZone: cleanText(body.timezone || 'Asia/Kolkata', 80),
        researchRequested: researchNeeded,
      });
      if (aiResult.ok) {
        aiReply = aiResult.text;
        aiModel = aiResult.model;
        aiWebSearchUsed = aiResult.webSearchUsed === true;
        aiSearchEvidence = Array.isArray(aiResult.sources) ? aiResult.sources.slice(0, 10) : [];
      } else if (aiResult.reason !== 'not_configured') {
        aiFailureReason = aiResult.reason;
        aiFailureMessage = cleanText(aiResult.message || '', 220) || null;
      }
    } catch (error) {
      aiFailureReason = 'ai_module_error';
    }
  }

'''
    text = text[:start] + ai_block + text[end:]
    text = replace_once(text,
        "  const noAiMessage = aiFailureReason\n    ? 'Gemini is temporarily unavailable (' + aiFailureReason + '). ' + (aiFailureMessage ? 'Provider detail: ' + aiFailureMessage + ' ' : '') + 'Please retry. The dashboard and local calculator remain available.'\n    : 'Gemini is not configured for this deployment. The site owner must add GEMINI_API_KEY to this Netlify project and redeploy.';",
        "  const noAiMessage = aiFailureReason\n    ? 'OpenRouter is temporarily unavailable (' + aiFailureReason + '). ' + (aiFailureMessage ? 'Provider detail: ' + aiFailureMessage + ' ' : '') + 'Please retry. The calculator and available research fallback remain available.'\n    : 'OpenRouter is not configured for this deployment. The site owner must add OPENROUTER_API_KEY to this Netlify project and redeploy.';",
        'Gemini chat fallback messages')
    text = replace_once(text,
        "  const aiNote = aiReply\n    ? null\n    : (aiFailureReason\n      ? 'Gemini error: ' + aiFailureReason + (aiFailureMessage ? ' — ' + aiFailureMessage : '') + '. Showing available calculator/research fallback instead.'\n      : (aiConfigured() ? null : 'No AI provider is configured yet (set AI_PROVIDER and GEMINI_API_KEY in Netlify); showing the deterministic research summary.'));",
        "  const aiNote = aiReply\n    ? null\n    : (aiFailureReason\n      ? 'OpenRouter error: ' + aiFailureReason + (aiFailureMessage ? ' — ' + aiFailureMessage : '') + '. Showing available calculator/research fallback instead.'\n      : (aiConfigured() ? null : 'OpenRouter is not configured yet (add OPENROUTER_API_KEY in Netlify); showing the deterministic research summary.'));",
        'Gemini aiNote fallback')
    text = replace_once(text,
        "  const evidence = [\n    ...(researchNeeded && research && research.showSources && Array.isArray(research.evidence)\n      ? research.evidence.slice(0, 12) : []),\n    ...aiGroundingEvidence\n  ].filter((item, index, all) => item && item.url && all.findIndex(other => other && other.url === item.url) === index).slice(0, 12);",
        "  const evidence = [\n    ...(researchNeeded && research && research.showSources && Array.isArray(research.evidence)\n      ? research.evidence.slice(0, 12) : []),\n    ...aiSearchEvidence\n  ].filter((item, index, all) => item && item.url && all.findIndex(other => other && other.url === item.url) === index).slice(0, 12);",
        'combined chat evidence')
    text = replace_once(text,
        "    source: aiReply ? (aiGroundingUsed ? 'gemini+google-search-grounding+background-research+calculator-context' : 'gemini+background-research+calculator-context') : 'background-research+calculator-context',",
        "    source: aiReply ? (aiWebSearchUsed ? 'openrouter+langsearch+background-research+calculator-context' : 'openrouter+background-research+calculator-context') : 'background-research+calculator-context',",
        'chat source label')
    text = replace_once(text,
        '    googleSearchGroundingUsed: aiGroundingUsed,',
        '    langSearchUsed: aiWebSearchUsed,',
        'Gemini grounding result flag')
    text = replace_once(text,
        "    privacy: 'The app sends only calculator totals, rule values, and limited badge titles to its own Netlify function (and, when an AI provider is configured, to that provider). Public research providers and the AI provider receive a redacted question and dashboard totals, not your profile URL, display name, email address, or Google login data.',",
        "    privacy: 'The app does not send your Google login data or read your email address from your profile. Common email addresses and Google Skills public-profile URLs are removed from chat text before it is sent to OpenRouter or LangSearch. Your chat question, recent conversation context, calculator totals and selected evidence may still be processed by those providers when configured; do not type confidential information into Arcade Buddy.',",
        'provider privacy disclosure')
    # The Gemini integration must be completely removed from this function.
    forbidden = ['GEMINI_API_KEY', 'GEMINI_MODEL', 'gemini-agent.mjs', 'generateGeminiAnswer', 'aiGroundingUsed', 'aiGroundingEvidence', 'googleSearchGroundingUsed']
    leftovers = [value for value in forbidden if value in text]
    if leftovers:
        raise SystemExit('Gemini remnants remain in intelligence.js: ' + ', '.join(leftovers))
    write('netlify/functions/intelligence.js', text)


def patch_package() -> None:
    data = json.loads(read('package.json'))
    if data.get('version') != EXPECTED_VERSION:
        raise SystemExit(f"Expected package version {EXPECTED_VERSION}, found {data.get('version')}.")
    data['version'] = NEW_VERSION
    data['description'] = 'Arcade Journey Tracker v9.3.0 Build 826 with OpenRouter + LangSearch Arcade Buddy and profile-ID automatic sync.'
    data['dependencies'] = {key: value for key, value in data.get('dependencies', {}).items() if key != '@netlify/identity'}
    data['scripts']['test'] = 'node tools/smoke-test.js && node tools/intelligence-test.js && node --test tools/arcade-buddy-test.mjs tools/profile-data-test.mjs tools/openrouter-langsearch-test.mjs && node tools/agent-review-test.js && node tools/build.js'
    check_parts = [
        'node --check netlify/lib/arcade-buddy/planner.mjs',
        'node --check netlify/lib/arcade-buddy/evidence.mjs',
        'node --check netlify/lib/arcade-buddy/providers.mjs',
        'node --check netlify/lib/arcade-buddy/strategy.mjs',
        'node --check netlify/lib/arcade-buddy/agent-core.mjs',
        'node --check netlify/lib/arcade-buddy/langsearch-provider.mjs',
        'node --check netlify/lib/arcade-buddy/openrouter-agent.mjs',
        'node --check netlify/functions/intelligence.js',
        'node --check netlify/functions/profile-data.mjs',
        'node --check netlify/functions/agent-review.js',
        'node --check netlify/functions/release.js',
        'node tools/build.js',
    ]
    data['scripts']['check'] = ' && '.join(check_parts)
    write('package.json', json.dumps(data, indent=2) + '\n')


def patch_build() -> None:
    text = read('tools/build.js')
    text = replace_once(text,
        "for (const name of ['arcade-buddy-ai.js', 'arcade-buddy-ai-worker.mjs', 'arcade-identity.js']) {",
        "for (const name of ['arcade-buddy-ai.js', 'arcade-buddy-ai-worker.mjs']) {",
        'browser module syntax-check list')
    text = replace_once(text,
        "for (const name of ['index.html', 'app-builtin.html', 'robots.txt', 'sitemap.xml', 'arcade-buddy-ai.js', 'arcade-buddy-ai-worker.mjs', 'arcade-identity.js']) {",
        "for (const name of ['index.html', 'app-builtin.html', 'robots.txt', 'sitemap.xml', 'arcade-buddy-ai.js', 'arcade-buddy-ai-worker.mjs']) {",
        'browser published files list')
    text = text.replace('private account-sync adapter', 'automatic public-profile-ID sync')
    if 'arcade-identity.js' in text:
        raise SystemExit('Build script still references the old Identity adapter.')
    write('tools/build.js', text)


def patch_tests() -> None:
    text = read('tools/intelligence-test.js')
    text = text.replace('Gemini is not configured', 'OpenRouter is not configured')
    start_comment = text.find('    // The Netlify function may check for the presence of')
    end_comment = text.find('  } finally {', start_comment)
    if start_comment < 0 or end_comment < 0:
        raise SystemExit('Could not locate the legacy provider test assertions.')
    replacement = """    // Provider calls and API credentials remain server-side, never in the browser.
    assert.doesNotMatch(fnText, /api\\.openrouter\\.ai|api\\.langsearch\\.com/);
    assert.doesNotMatch(appText, /OPENROUTER_API_KEY|LANGSEARCH_API_KEY|api\\.openrouter\\.ai|api\\.langsearch\\.com/);
    assert.doesNotMatch(indexText, /OPENROUTER_API_KEY|LANGSEARCH_API_KEY|api\\.openrouter\\.ai|api\\.langsearch\\.com/);
"""
    text = text[:start_comment] + replacement + text[end_comment:]
    text = re.sub(r'Gemini|gemini|GEMINI|generativelanguage', 'OpenRouter', text)
    write('tools/intelligence-test.js', text)

    text = read('tools/smoke-test.js')
    text = text.replace("assert.strictEqual(pkg.version, '9.2.0', 'package release version');", "assert.strictEqual(pkg.version, '9.3.0', 'package release version');")
    text = text.replace('matchBuild(app), 825', 'matchBuild(app), 826').replace('matchBuild(index), 825', 'matchBuild(index), 826')
    text = text.replace('/var BASE_BUILD = 825/', '/var BASE_BUILD = 826')
    text = text.replace('/const BASE_BUILD\\s*=\\s*825/', '/const BASE_BUILD\\s*=\\s*826/')
    text = text.replace('const STORE_NAME = \"arcade-user-profiles\"', "const STORE_NAME = 'arcade-profile-id-sync'")
    text = text.replace('/@netlify\\/identity/', '/onlyIfMatch/')
    text = text.replace('/getUser\\(\\)/', '/onlyIfNew/')
    text = text.replace('/accountPrefix/', '/public profile ID/')
    text = text.replace('/consistency: \"strong\"/', "/consistency: 'strong'/")
    text = text.replace("assert.match(read('tools/build.js'), /arcade-identity\\.js/);\nassert.match(read('package.json'), /\"@netlify\\/identity\"/);",
                        "assert.doesNotMatch(read('tools/build.js'), /arcade-identity\\.js/);\nassert.doesNotMatch(read('package.json'), /@netlify\\/identity/);")
    text = text.replace('saved cloud backup', 'saved profile-ID sync records')
    text = text.replace('synchronized build 825', 'synchronized build 826').replace('private Identity-backed cloud sync', 'public-profile-ID automatic sync')
    write('tools/smoke-test.js', text)

    profile_test = read('tools/profile-data-test.mjs')
    if "recordKey(uid)" not in profile_test or "version, 2" not in profile_test:
        raise SystemExit('New profile-data tests were not copied into place.')


def patch_release() -> None:
    text = read('netlify/functions/release.js')
    text = replace_once(text, 'const BASE_BUILD = 825;', 'const BASE_BUILD = 826;', 'Hot Update base build')
    write('netlify/functions/release.js', text)


def patch_readme() -> None:
    text = r'''# Arcade Journey Tracker v9.3.0 — Build 826

Full-source Netlify application: Google Skills Arcade points calculator, seasonal artwork, manual bonus points, badge overrides and learned classifications, Developer Mode, Hot Update Manager, Arcade Buddy, approved-knowledge research, and the separate per-item Arcade Intelligence owner-review flow.

## v9.3.0 changes

- Replaces the Gemini integration with **OpenRouter + LangSearch**. OpenRouter runs the chat/reasoning step; LangSearch supplies live web results for research requests. Existing background research and the owner-approved Arcade knowledge feed remain available as separate evidence sources.
- Removes Gemini provider code, Gemini API configuration and Netlify Identity email/password account UI.
- Adds automatic profile-ID sync: local changes are stored immediately in the browser and synced to Netlify Blobs in the background for the current Google Skills public profile ID. Opening the same public profile on another device restores the saved manual points, overrides, learned classifications, goals, settings, keyword lists, snapshots and updates.
- Adds revision-based conditional writes. If another device updates the same profile first, the later write is rejected rather than silently overwriting the latest saved record.
- Keeps Developer Mode, calculator logic, Hot Updates, seasonal assets and owner-review email processing. The separate `arcade-intelligence-2.0` repository is not modified.
- Updates the release baseline to Build 826.

## Important profile-ID sync privacy note

This release uses the Google Skills **public profile ID as the storage locator**, not as proof that the caller owns the profile. There is no email/password prompt. However, the public ID is not a secret: anyone who knows it may be able to read, overwrite or delete the saved sync record. Use this feature only for non-sensitive calculator state. Do not store passwords, API keys, private messages, or other confidential information in it.

The browser keeps a local copy and the sync function applies size limits, input validation, same-origin checks, request throttling and conditional revision writes. These protections reduce accidental data loss and abuse; they do **not** make a public-ID record private or prove profile ownership. Netlify Blobs is the shared backend store named `arcade-profile-id-sync`.

Older v9.2.0 Identity-backed records in `arcade-user-profiles` are left untouched; this release does not automatically read or migrate those account-protected records. The original device's browser-local state will be uploaded when that device opens the profile in this release. If the only copy of some manual changes exists in the old Identity cloud account, open the old v9.2.0 app on the already-signed-in device first and confirm those changes have been restored into that browser before replacing the old version. Do not assume the new public-ID store can read the old account-protected records.

## Deploy through GitHub

This is a **full-source update**, not a static HTML-only Hot Update. The update ZIP is a guarded patch payload that GitHub Actions applies to the existing repository checkout, then tests and commits. It is not the final Netlify publish directory by itself.

1. Open `SubratNexus/arcade-journey-tracker-app` and use branch `main`.
2. Upload `import-final-v9.3.0.yml` to `.github/workflows/` with that exact filename and commit it.
3. Upload `Arcade-Journey-Tracker-v9.3.0-OpenRouter-LangSearch-Profile-ID-Sync-Build-826.zip` to the repository root and commit it.
4. Open GitHub → Actions and inspect **Import Arcade Journey Tracker v9.3.0**. The job validates the archive, applies the update, runs `npm run check` and `npm test`, removes the temporary upload, commits the updated full source to `main`, and attaches a full-source ZIP artifact to the successful workflow run.
5. If the workflow is green and your Netlify site is connected to this repository's `main` branch, Netlify should start its normal continuous deployment. Confirm the Netlify production deploy is published before sharing the app URL.

Do not upload this project to `arcade-intelligence-2.0`. Do not deploy only `dist/`; it is generated by `node tools/build.js`. If the importer workflow fails, do not try to manually deploy a partial tree. Read the failed Actions step first. Branch protection or GitHub App permissions can prevent the workflow from committing even after tests pass.

## Netlify environment variables

Set these in the Netlify site connected to the calculator repository. Choose the **Production** context and **Functions** scope. Values are entered directly in Netlify; never put them in GitHub files, HTML, browser storage or chat messages.

| Variable | Type | Purpose |
|---|---|---|
| `OPENROUTER_API_KEY` | Secret | Required OpenRouter server key. |
| `LANGSEARCH_API_KEY` | Secret | Required for LangSearch live web research. |
| `OPENROUTER_MODEL` | Plain variable; optional | Defaults to `openrouter/free`. |
| `SITE_URL` | Plain variable; optional | Your deployed HTTPS app origin for OpenRouter request metadata. |
| `SITE_NAME` | Plain variable; optional | Display name sent as request metadata. |

The browser never receives the API keys. The OpenRouter and LangSearch calls run in Netlify Functions. No `AI_PROVIDER`, `GEMINI_API_KEY`, `GEMINI_MODEL`, or `@netlify/identity` setup is required by this release. Remove obsolete Gemini variables from the Netlify project's Functions environment after the new release is deployed.

**Free-tier limits still apply.** `openrouter/free` routes to available free models and can be rate-limited, unavailable, or changed by the provider. LangSearch's free API has usage limits and request throttles. This is not an unlimited or guaranteed-uptime AI service; the chatbot falls back to the app's deterministic/research answer when the external AI path is unavailable. Keep Netlify auto-recharge disabled if you want to avoid automatic spending, and monitor usage in both provider dashboards.

## Arcade Buddy evidence policy

- Arcade Buddy combines the calculator context, the existing background research pipeline, and the owner-approved `agent-data/approved-knowledge.json` source from `SubratNexus/arcade-intelligence-2.0`.
- `public-feed.json` and `review-queue.json` are discovery/proposal sources, not approved facts. Pending proposals are not promoted into chatbot-approved knowledge.
- LangSearch results are labelled as unverified search results. A Google-owned domain can be marked an official candidate, but search results alone do not prove a programme rule, participant eligibility, a reward, point value or live availability.
- Community posts remain community evidence. A report or rumour is not an official announcement.
- The AI provider may be unavailable or return incomplete information. Check original official sources for deadlines and eligibility.

## Other existing systems

- **Hot Update Manager:** remains separate at `/api/release`. It can deliver supported HTML-only app updates; it cannot replace Netlify Functions or dependencies.
- **Arcade Intelligence owner review:** remains separate at `/api/agent-review`. Each email review action still requires an explicit second confirmation. Its GitHub agent repository remains `SubratNexus/arcade-intelligence-2.0`.
- **Local browser model:** the optional `arcade-buddy-ai.js` / WebLLM files are preserved. They are separate from the hosted OpenRouter integration and require a compatible browser/device; the app should not assume WebGPU is available.
- **Profile sync:** manual changes remain in local browser storage immediately. Cloud sync is attempted after the current profile has first been checked, and after subsequent changes. Offline changes remain local until the browser is online. If the server reports a cross-device revision conflict, the app protects the remote record rather than silently forcing a stale write.

## Checks

Requires Node.js 20 or newer.

```bash
npm install
npm run check
npm test
```

The GitHub Actions workflow runs the full repository check/test suite before committing. Those checks validate source logic and build output; they do not guarantee that live API keys, provider quotas, Netlify permissions, DNS, or a production deployment will work. After deploy, test a profile sync by adding a harmless manual change on one device, opening the same public Google Skills profile on a second browser/device, and verifying restoration. Do not use confidential data for this test.

Never commit `.env` files, API keys, GitHub tokens, developer passwords, or secret values.
'''
    write('README.md', text)


def main() -> None:
    package = json.loads(read('package.json'))
    if package.get('version') != EXPECTED_VERSION:
        raise SystemExit(f"Expected source version {EXPECTED_VERSION}; found {package.get('version')}.")
    if 'name="app-build" content="825"' not in read('index.html'):
        raise SystemExit('Expected Build 825 HTML source; no files have been changed.')

    copy_payload()
    patch_html('index.html')
    patch_html('app-builtin.html')
    patch_intelligence()
    patch_package()
    patch_build()
    patch_tests()
    patch_release()
    patch_readme()

    # Remove only the obsolete Identity/Gemini integration modules and their dedicated test.
    for relative in [
        'arcade-identity.js',
        'netlify/lib/arcade-buddy/gemini-agent.mjs',
        'netlify/lib/arcade-buddy/gemini-provider.mjs',
        'tools/gemini-test.mjs',
        '.github/workflows/bootstrap-zip.yml',
    ]:
        target = ROOT / relative
        if target.exists(): target.unlink()

    # Ensure no remaining source loads the email/password adapter or Gemini modules/keys.
    scan_paths = [
        'index.html', 'app-builtin.html', 'package.json', 'tools/build.js',
        'netlify/functions/intelligence.js', 'netlify/functions/profile-data.mjs',
    ]
    forbidden = ['GEMINI_API_KEY', 'GEMINI_MODEL', 'gemini-agent.mjs', 'gemini-provider.mjs', 'arcade-identity.js', 'generateGeminiAnswer']
    for relative in scan_paths:
        content = read(relative)
        bad = [token for token in forbidden if token in content]
        if bad:
            raise SystemExit(f'Unexpected legacy integration reference in {relative}: {", ".join(bad)}')

    print('Applied Arcade Journey Tracker v9.3.0 / Build 826 source update.')
    print('Next required verification: npm run check && npm test (performed by the GitHub Actions importer).')


if __name__ == '__main__':
    main()
